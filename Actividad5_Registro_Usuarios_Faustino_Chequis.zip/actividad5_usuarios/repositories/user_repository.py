"""Repositorio responsable de almacenar y consultar usuarios."""
from uuid import UUID
from models.user import User

class UserRepository:
    def __init__(self):
        self._users: list[User] = []

    def find_all(self) -> list[User]:
        return self._users

    def create_one(self, user: User) -> None:
        self._users.append(user)

    def delete_one(self, user_id: UUID) -> None:
        self._users = [user for user in self._users if user.id != user_id]
