"""Entidad que representa a un usuario."""
from dataclasses import dataclass, field
from uuid import UUID, uuid4

@dataclass
class User:
    name: str
    last_name: str
    age: int
    email: str
    id: UUID = field(default_factory=uuid4)
