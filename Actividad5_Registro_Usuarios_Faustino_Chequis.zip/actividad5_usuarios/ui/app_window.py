"""Ventana principal para visualizar, crear y eliminar usuarios."""
import tkinter as tk
from tkinter import ttk, messagebox
from uuid import UUID
from services.user_service import UserService

class AppWindow(tk.Tk):
    def __init__(self, service: UserService):
        super().__init__()
        self.service = service
        self.title("Sistema de registro de usuarios - Actividad 5")
        self.geometry("900x570")
        self.minsize(760, 480)
        self.configure(padx=18, pady=18)
        self._build_interface()
        self.refresh_table()

    def _build_interface(self):
        ttk.Label(self, text="SISTEMA DE REGISTRO DE USUARIOS",
                  font=("Arial", 18, "bold")).pack(pady=(0, 15))

        form = ttk.LabelFrame(self, text="Registrar usuario", padding=12)
        form.pack(fill="x", pady=(0, 15))

        fields = [
            ("Nombre:", "name_entry"),
            ("Apellido:", "last_name_entry"),
            ("Edad:", "age_entry"),
            ("Correo electrónico:", "email_entry"),
        ]
        for row, (label, attr) in enumerate(fields):
            ttk.Label(form, text=label).grid(row=row, column=0, sticky="w", padx=5, pady=5)
            entry = ttk.Entry(form)
            entry.grid(row=row, column=1, sticky="ew", padx=5, pady=5)
            setattr(self, attr, entry)
        form.columnconfigure(1, weight=1)

        ttk.Button(form, text="Crear usuario", command=self.create_user).grid(
            row=4, column=1, sticky="e", padx=5, pady=(8, 2)
        )

        table_frame = ttk.LabelFrame(self, text="Usuarios registrados", padding=10)
        table_frame.pack(fill="both", expand=True)

        self.tree = ttk.Treeview(
            table_frame,
            columns=("id", "name", "last_name", "age", "email"),
            show="headings",
            height=12
        )
        headings = {
            "id": ("ID", 185),
            "name": ("Nombre", 125),
            "last_name": ("Apellido", 125),
            "age": ("Edad", 60),
            "email": ("Correo electrónico", 230),
        }
        for column, (heading, width) in headings.items():
            self.tree.heading(column, text=heading)
            self.tree.column(column, width=width, anchor="center" if column in ("id", "age") else "w")

        scrollbar = ttk.Scrollbar(table_frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scrollbar.set)
        self.tree.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        ttk.Button(self, text="Eliminar usuario seleccionado",
                   command=self.delete_user).pack(anchor="e", pady=(12, 0))

    def create_user(self):
        try:
            self.service.create_one(
                self.name_entry.get(),
                self.last_name_entry.get(),
                self.age_entry.get(),
                self.email_entry.get()
            )
            self.clear_entries()
            self.refresh_table()
            messagebox.showinfo("Registro correcto", "El usuario se creó correctamente.")
        except ValueError as error:
            messagebox.showwarning("No se pudo registrar", str(error))

    def refresh_table(self):
        for item in self.tree.get_children():
            self.tree.delete(item)
        for user in self.service.find_all():
            self.tree.insert(
                "", "end",
                values=(str(user.id), user.name, user.last_name, user.age, user.email)
            )

    def delete_user(self):
        selection = self.tree.selection()
        if not selection:
            messagebox.showwarning("Selección requerida", "Selecciona un usuario de la tabla.")
            return
        values = self.tree.item(selection[0], "values")
        self.service.delete_one(UUID(values[0]))
        self.refresh_table()
        messagebox.showinfo("Registro eliminado", "El usuario se eliminó correctamente.")

    def clear_entries(self):
        for entry in (self.name_entry, self.last_name_entry, self.age_entry, self.email_entry):
            entry.delete(0, tk.END)
        self.name_entry.focus()
