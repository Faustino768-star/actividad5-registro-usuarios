"""Servicio con las reglas de negocio de los usuarios."""
from models.user import User
from repositories.user_repository import UserRepository
from uuid import UUID

class UserService:
    def __init__(self, repository: UserRepository):
        self.repository = repository

    def find_all(self) -> list[User]:
        return self.repository.find_all()

    def create_one(self, name: str, last_name: str, age: str, email: str) -> None:
        name = name.strip()
        last_name = last_name.strip()
        email = email.strip()
        if not name or not last_name or not age.strip() or not email:
            raise ValueError("Completa todos los campos.")
        try:
            age_number = int(age)
        except ValueError:
            raise ValueError("La edad debe ser un número entero.")
        if age_number < 1 or age_number > 120:
            raise ValueError("Introduce una edad válida entre 1 y 120 años.")
        if "@" not in email or "." not in email.split("@")[-1]:
            raise ValueError("Introduce un correo electrónico válido.")
        user = User(name=name, last_name=last_name, age=age_number, email=email)
        self.repository.create_one(user)

    def delete_one(self, user_id: UUID) -> None:
        self.repository.delete_one(user_id)
