# Actividad 5: Visualización y creación de usuarios

## Descripción
Desarrollé una aplicación de escritorio para registrar y visualizar usuarios utilizando Python, Tkinter y programación orientada a objetos (POO). Los registros se muestran en una tabla `Treeview`.

## Funcionalidades
- Listar usuarios en una tabla.
- Crear usuarios mediante campos de entrada.
- Validar los datos antes de registrar.
- Actualizar la tabla después de crear un usuario.
- Eliminar el usuario seleccionado.

## Datos del usuario
La entidad `User` contiene nombre, apellido, edad y correo electrónico, además de un identificador único.

## Arquitectura
- `models/`: contiene la entidad `User`.
- `repositories/`: administra el almacenamiento de usuarios.
- `services/`: contiene las reglas de negocio y validaciones.
- `ui/`: construye la interfaz gráfica y consume el servicio.
- `main.py`: conecta las capas e inicia la aplicación.

La clase `AppWindow` interactúa con `UserService`, no accede directamente al repositorio.

## Requisitos
- Python 3.10 o superior.
- Tkinter.

## Ejecución
Desde la carpeta del proyecto, ejecutar:

```bash
python main.py
```

## Prueba
1. Ejecutar la aplicación.
2. Completar nombre, apellido, edad y correo electrónico.
3. Presionar **Crear usuario**.
4. Verificar que el usuario aparezca en el Treeview.
5. Seleccionar una fila y presionar **Eliminar usuario seleccionado**.

## Almacenamiento
Los datos se guardan en memoria durante la ejecución. Al cerrar el programa, los registros se reinician. No se utiliza una base de datos en esta actividad.
